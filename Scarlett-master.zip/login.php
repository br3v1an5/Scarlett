<?php include 'includes/functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
		<!-- head -->
		<title>OWL Internet | Best cPanel Hosting with 24x7 live support</title>
		<!-- include Depedencies -->
    <?php include 'includes/common-header.php'; ?>
		<!-- /.include Depedencies and nav-->


		<!-- CONTENTS -->
		<div class="hero-slider stick-dots">
			<div class="slides">

			</div>
			<div class="slides">

			</div>
  	</div>
		<div class="container">
      <div class="row">
          <div class="col-md-6">
              <div class="login-aside">

              </div>
          </div>
          <div class="col-md-6">
              <div class="login">
                <form>
                <div class="form-group">
                  <label for="email">Email address:</label>
                  <input type="email" class="form-control" id="email">
                </div>
                <div class="form-group">
                  <label for="pwd">Password:</label>
                  <input type="password" class="form-control" id="pwd">
                </div>
                <div class="checkbox">
                  <label><input type="checkbox"> Remember me</label>
                </div>
                <button type="submit" class="btn btn-default">Submit</button>
                </form>
              </div>
          </div>
      </div>
		</div>
		<!-- /.content -->
    <!-- include scripts -->
   	<?php include 'includes/common-footer.php'; ?>
		<!-- /.indlude scripts -->
  </body>
</html>
