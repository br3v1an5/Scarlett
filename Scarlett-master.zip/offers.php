<?php
  header('location:coming-soon');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
		<!-- head -->
		<title>Scarlett | Promos & Offers</title>
		<!-- include Depedencies -->
		<?php include 'includes/functions.php'; ?>
		<?php include 'includes/common-header.php'; ?>
		<!-- /.include Depedencies and nav-->


		<!-- CONTENTS -->

<div class="">
    <div class="container">

    </div>
</div>
		<!-- /.content -->
    <!-- include scripts -->
   	<?php include 'includes/common-footer.php'; ?>
		<!-- /.indlude scripts -->
