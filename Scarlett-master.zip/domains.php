<?php include 'includes/functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
		<!-- head -->
		<title>Scarlett | Best cPanel Hosting with 24x7 live support</title>
		<!-- include Depedencies -->
    <?php include 'includes/common-header.php'; ?>
		<!-- /.include Depedencies and nav-->


		<!-- CONTENTS -->
		<div class="hero-slider stick-dots">
			<div class="slides">

			</div>
			<div class="slides">

			</div>
  	</div>
		<div class="container">
      <!--?php echo $domainpricing; ?-->
      <?php echo $domainsearch; ?>
		  </div>
		<!-- /.content -->
    <!-- include scripts -->
   	<?php include 'includes/common-footer.php'; ?>
		<!-- /.indlude scripts -->
  </body>
</html>
