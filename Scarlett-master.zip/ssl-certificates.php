<?php
  header('location:coming-soon');
?>
