<?php
/* global varriables */
$logo = "./assets/images/logo.png";
$logo_white = "./assets/images/logo-white.png";
$current_promo = "./assets/images/promos/bells.svg";
/* # global varriables */
	$id = $_GET['from'];
	if ($id == '1.0') {
		echo 'Welcome to OWL Internet 2.0';
	}
	/* pricing */
	// Shared pricing
	$boat_m = "2.99";
	$boat_y = "29.99";
	$yacht_m = "5.99";
	$yacht_y = "59.99";
	$cruise_m = "9.99";
	$cruise_y = "99.99";
	//reseller Pricing
	$mercury_m = "2.99";
	$mercury_y = "29.99";
	$earth_m = "5.99";
	$earth_y = "59.99";
	$jupiter_m = "9.99";
	$jupiter_y = "99.99";
	// Domain
	$com = "13.99";
	$net = "14.99";
	$org = "34.99";
	$in = "15.99";
?>
