<?php
require("/home/owlinter/public_html/my/init.php");
require("/home/owlinter/public_html/my/includes/domainfunctions.php");
?>
