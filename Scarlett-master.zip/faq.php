<?php include 'includes/functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
		<!-- head -->
		<title>Scarlett | Best cPanel Hosting with 24x7 live support</title>
		<!-- include Depedencies -->
    <?php include 'includes/common-header.php'; ?>
		<!-- /.include Depedencies and nav-->


		<!-- CONTENTS -->
		<div class="hero-slider stick-dots">
			<div class="slides">

			</div>
			<div class="slides">

			</div>
  	</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc facilisis, turpis eu placerat laoreet, augue lorem blandit enim, et blandit arcu nibh ut velit. Ut eget nunc porttitor, mattis lorem eget, interdum turpis. Nam aliquam augue dui, quis posuere erat porta a. Phasellus sodales metus elit, pellentesque mattis ipsum congue at. Maecenas luctus felis at efficitur bibendum. In ac est a ex condimentum tempor. Nulla pellentesque arcu sed varius tristique. Pellentesque gravida mauris hendrerit turpis finibus, a hendrerit arcu euismod.

Aliquam condimentum ligula vel diam elementum dignissim. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Morbi sit amet tempor ligula. Aenean at pharetra turpis. Suspendisse hendrerit velit nec neque imperdiet egestas. Phasellus id dui arcu. In eu turpis placerat, condimentum nunc in, egestas tellus. Nullam ornare eros placerat, posuere arcu vitae, euismod ipsum. Aenean porta ex id massa mollis, eu fringilla sapien auctor.

Nulla facilisi. Nulla rhoncus quam et leo aliquet consequat. Nullam sagittis porttitor dui, eget porttitor mi aliquet eget. Donec scelerisque nisi elit, vitae imperdiet mi vehicula sit amet. Vivamus sodales pulvinar nunc quis fringilla. Integer id quam arcu. Nulla porta vulputate ornare. Donec nec aliquam orci, eu imperdiet nisi. Phasellus ac posuere massa, in tempor mi. Vestibulum orci lectus, suscipit feugiat fermentum quis, maximus et ante. Proin convallis quis mauris quis tristique. Suspendisse in metus vel velit sagittis hendrerit id ac lorem. Nulla facilisi. Aenean ac egestas odio, et consequat ipsum. Fusce mattis pretium tempor. Vivamus eget accumsan orci, vitae varius leo.

Suspendisse id eros dolor. Donec tincidunt est nec lectus posuere condimentum. Phasellus tempor, tortor in eleifend vulputate, ligula dolor viverra urna, at ultrices erat arcu eu dolor. Duis hendrerit neque eu elit feugiat viverra a sit amet mauris. Curabitur vitae ultrices lacus. Integer id velit eleifend, posuere velit at, placerat urna. Donec felis magna, faucibus eu leo vel, tempor bibendum nibh.

Pellentesque imperdiet vehicula turpis ut rutrum. Integer euismod interdum justo, vitae volutpat ipsum condimentum vel. Quisque et accumsan massa. Nullam euismod at sem ac consequat. Fusce ullamcorper vestibulum urna non gravida. In hac habitasse platea dictumst. Sed eget nibh nec neque pretium vestibulum. Nam placerat nibh vitae nibh porta, in ultricies dui malesuada.

Aenean congue faucibus tortor convallis blandit. Pellentesque a ultrices mi. Suspendisse libero erat, lobortis vel magna a, tincidunt accumsan nisl. Etiam sed ligula odio. Cras condimentum arcu lorem, eu vulputate quam volutpat eget. Vestibulum eu molestie risus. Nam a urna elementum, hendrerit neque sit amet, fermentum augue.

Sed fringilla orci nisl. Curabitur luctus ipsum erat, vel scelerisque erat posuere lacinia. Etiam malesuada egestas urna, sit amet dapibus eros faucibus sed. Maecenas auctor ante in augue faucibus, id bibendum tellus pretium. Donec vitae tincidunt sapien. Donec at est nisl. Ut vitae orci a orci sodales dignissim ac a mi. Aliquam laoreet ante turpis, ultricies mattis erat ultrices et. Integer justo sem, mollis porta cursus vitae, ornare ut felis. Maecenas imperdiet odio eget orci congue sagittis. Curabitur at faucibus arcu, quis iaculis quam. Vestibulum eleifend ornare felis eget commodo. Sed tristique id turpis sed viverra. Sed quis quam non velit fringilla accumsan at nec mauris.

Pellentesque elementum eros vel orci luctus consequat euismod sit amet elit. Phasellus eget lorem vel nunc blandit ultrices. Nunc interdum purus nulla, et vestibulum lacus facilisis euismod. Quisque at blandit arcu. Vestibulum non lobortis nibh, sed cursus justo. Nunc quis leo auctor, imperdiet nulla et, porta quam. Duis vel ipsum non lacus iaculis bibendum ac ac nibh. Curabitur quis nisl sem. Phasellus nec tortor tellus.

Curabitur vel orci et sem finibus euismod id eget elit. Mauris est massa, accumsan quis pharetra vitae, aliquam iaculis nisi. Vivamus luctus dapibus ipsum sit amet laoreet. Fusce convallis sodales facilisis. Nullam pellentesque, ligula et hendrerit egestas, dolor diam dapibus leo, sit amet feugiat est metus sed purus. Phasellus iaculis neque sit amet urna aliquet pharetra. Nam at feugiat enim. Nam eget eros dictum elit porttitor congue a eget nibh.

Quisque ut nunc in enim fermentum
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc facilisis, turpis eu placerat laoreet, augue lorem blandit enim, et blandit arcu nibh ut velit. Ut eget nunc porttitor, mattis lorem eget, interdum turpis. Nam aliquam augue dui, quis posuere erat porta a. Phasellus sodales metus elit, pellentesque mattis ipsum congue at. Maecenas luctus felis at efficitur bibendum. In ac est a ex condimentum tempor. Nulla pellentesque arcu sed varius tristique. Pellentesque gravida mauris hendrerit turpis finibus, a hendrerit arcu euismod.

Aliquam condimentum ligula vel diam elementum dignissim. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Morbi sit amet tempor ligula. Aenean at pharetra turpis. Suspendisse hendrerit velit nec neque imperdiet egestas. Phasellus id dui arcu. In eu turpis placerat, condimentum nunc in, egestas tellus. Nullam ornare eros placerat, posuere arcu vitae, euismod ipsum. Aenean porta ex id massa mollis, eu fringilla sapien auctor.

Nulla facilisi. Nulla rhoncus quam et leo aliquet consequat. Nullam sagittis porttitor dui, eget porttitor mi aliquet eget. Donec scelerisque nisi elit, vitae imperdiet mi vehicula sit amet. Vivamus sodales pulvinar nunc quis fringilla. Integer id quam arcu. Nulla porta vulputate ornare. Donec nec aliquam orci, eu imperdiet nisi. Phasellus ac posuere massa, in tempor mi. Vestibulum orci lectus, suscipit feugiat fermentum quis, maximus et ante. Proin convallis quis mauris quis tristique. Suspendisse in metus vel velit sagittis hendrerit id ac lorem. Nulla facilisi. Aenean ac egestas odio, et consequat ipsum. Fusce mattis pretium tempor. Vivamus eget accumsan orci, vitae varius leo.

Suspendisse id eros dolor. Donec tincidunt est nec lectus posuere condimentum. Phasellus tempor, tortor in eleifend vulputate, ligula dolor viverra urna, at ultrices erat arcu eu dolor. Duis hendrerit neque eu elit feugiat viverra a sit amet mauris. Curabitur vitae ultrices lacus. Integer id velit eleifend, posuere velit at, placerat urna. Donec felis magna, faucibus eu leo vel, tempor bibendum nibh.

Pellentesque imperdiet vehicula turpis ut rutrum. Integer euismod interdum justo, vitae volutpat ipsum condimentum vel. Quisque et accumsan massa. Nullam euismod at sem ac consequat. Fusce ullamcorper vestibulum urna non gravida. In hac habitasse platea dictumst. Sed eget nibh nec neque pretium vestibulum. Nam placerat nibh vitae nibh porta, in ultricies dui malesuada.

Aenean congue faucibus tortor convallis blandit. Pellentesque a ultrices mi. Suspendisse libero erat, lobortis vel magna a, tincidunt accumsan nisl. Etiam sed ligula odio. Cras condimentum arcu lorem, eu vulputate quam volutpat eget. Vestibulum eu molestie risus. Nam a urna elementum, hendrerit neque sit amet, fermentum augue.

Sed fringilla orci nisl. Curabitur luctus ipsum erat, vel scelerisque erat posuere lacinia. Etiam malesuada egestas urna, sit amet dapibus eros faucibus sed. Maecenas auctor ante in augue faucibus, id bibendum tellus pretium. Donec vitae tincidunt sapien. Donec at est nisl. Ut vitae orci a orci sodales dignissim ac a mi. Aliquam laoreet ante turpis, ultricies mattis erat ultrices et. Integer justo sem, mollis porta cursus vitae, ornare ut felis. Maecenas imperdiet odio eget orci congue sagittis. Curabitur at faucibus arcu, quis iaculis quam. Vestibulum eleifend ornare felis eget commodo. Sed tristique id turpis sed viverra. Sed quis quam non velit fringilla accumsan at nec mauris.

Pellentesque elementum eros vel orci luctus consequat euismod sit amet elit. Phasellus eget lorem vel nunc blandit ultrices. Nunc interdum purus nulla, et vestibulum lacus facilisis euismod. Quisque at blandit arcu. Vestibulum non lobortis nibh, sed cursus justo. Nunc quis leo auctor, imperdiet nulla et, porta quam. Duis vel ipsum non lacus iaculis bibendum ac ac nibh. Curabitur quis nisl sem. Phasellus nec tortor tellus.

Curabitur vel orci et sem finibus euismod id eget elit. Mauris est massa, accumsan quis pharetra vitae, aliquam iaculis nisi. Vivamus luctus dapibus ipsum sit amet laoreet. Fusce convallis sodales facilisis. Nullam pellentesque, ligula et hendrerit egestas, dolor diam dapibus leo, sit amet feugiat est metus sed purus. Phasellus iaculis neque sit amet urna aliquet pharetra. Nam at feugiat enim. Nam eget eros dictum elit porttitor congue a eget nibh.

Quisque ut nunc in enim fermentumconvallis vitae et neque. In tincidunt commodo orci maximus rhoncus. Proin porttitor nisl porttitor, condimentum mi a, elementum nibh. Donec sit amet efficitur nisl. Sed consectetur, mi sed condimentum suscipit, sem felis pulvinar mi, et consectetur metus turpis quis lectus. In sed lorem mi. Vivamus quis mi non velit gravida faucibus. Curabitur sed laoreet lectus.
		Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc facilisis, turpis eu placerat laoreet, augue lorem blandit enim, et blandit arcu nibh ut velit. Ut eget nunc porttitor, mattis lorem eget, interdum turpis. Nam aliquam augue dui, quis posuere erat porta a. Phasellus sodales metus elit, pellentesque mattis ipsum congue at. Maecenas luctus felis at efficitur bibendum. In ac est a ex condimentum tempor. Nulla pellentesque arcu sed varius tristique. Pellentesque gravida mauris hendrerit turpis finibus, a hendrerit arcu euismod.

Aliquam condimentum ligula vel diam elementum dignissim. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Morbi sit amet tempor ligula. Aenean at pharetra turpis. Suspendisse hendrerit velit nec neque imperdiet egestas. Phasellus id dui arcu. In eu turpis placerat, condimentum nunc in, egestas tellus. Nullam ornare eros placerat, posuere arcu vitae, euismod ipsum. Aenean porta ex id massa mollis, eu fringilla sapien auctor.

Nulla facilisi. Nulla rhoncus quam et leo aliquet consequat. Nullam sagittis porttitor dui, eget porttitor mi aliquet eget. Donec scelerisque nisi elit, vitae imperdiet mi vehicula sit amet. Vivamus sodales pulvinar nunc quis fringilla. Integer id quam arcu. Nulla porta vulputate ornare. Donec nec aliquam orci, eu imperdiet nisi. Phasellus ac posuere massa, in tempor mi. Vestibulum orci lectus, suscipit feugiat fermentum quis, maximus et ante. Proin convallis quis mauris quis tristique. Suspendisse in metus vel velit sagittis hendrerit id ac lorem. Nulla facilisi. Aenean ac egestas odio, et consequat ipsum. Fusce mattis pretium tempor. Vivamus eget accumsan orci, vitae varius leo.

Suspendisse id eros dolor. Donec tincidunt est nec lectus posuere condimentum. Phasellus tempor, tortor in eleifend vulputate, ligula dolor viverra urna, at ultrices erat arcu eu dolor. Duis hendrerit neque eu elit feugiat viverra a sit amet mauris. Curabitur vitae ultrices lacus. Integer id velit eleifend, posuere velit at, placerat urna. Donec felis magna, faucibus eu leo vel, tempor bibendum nibh.

Pellentesque imperdiet vehicula turpis ut rutrum. Integer euismod interdum justo, vitae volutpat ipsum condimentum vel. Quisque et accumsan massa. Nullam euismod at sem ac consequat. Fusce ullamcorper vestibulum urna non gravida. In hac habitasse platea dictumst. Sed eget nibh nec neque pretium vestibulum. Nam placerat nibh vitae nibh porta, in ultricies dui malesuada.

Aenean congue faucibus tortor convallis blandit. Pellentesque a ultrices mi. Suspendisse libero erat, lobortis vel magna a, tincidunt accumsan nisl. Etiam sed ligula odio. Cras condimentum arcu lorem, eu vulputate quam volutpat eget. Vestibulum eu molestie risus. Nam a urna elementum, hendrerit neque sit amet, fermentum augue.

Sed fringilla orci nisl. Curabitur luctus ipsum erat, vel scelerisque erat posuere lacinia. Etiam malesuada egestas urna, sit amet dapibus eros faucibus sed. Maecenas auctor ante in augue faucibus, id bibendum tellus pretium. Donec vitae tincidunt sapien. Donec at est nisl. Ut vitae orci a orci sodales dignissim ac a mi. Aliquam laoreet ante turpis, ultricies mattis erat ultrices et. Integer justo sem, mollis porta cursus vitae, ornare ut felis. Maecenas imperdiet odio eget orci congue sagittis. Curabitur at faucibus arcu, quis iaculis quam. Vestibulum eleifend ornare felis eget commodo. Sed tristique id turpis sed viverra. Sed quis quam non velit fringilla accumsan at nec mauris.

Pellentesque elementum eros vel orci luctus consequat euismod sit amet elit. Phasellus eget lorem vel nunc blandit ultrices. Nunc interdum purus nulla, et vestibulum lacus facilisis euismod. Quisque at blandit arcu. Vestibulum non lobortis nibh, sed cursus justo. Nunc quis leo auctor, imperdiet nulla et, porta quam. Duis vel ipsum non lacus iaculis bibendum ac ac nibh. Curabitur quis nisl sem. Phasellus nec tortor tellus.

Curabitur vel orci et sem finibus euismod id eget elit. Mauris est massa, accumsan quis pharetra vitae, aliquam iaculis nisi. Vivamus luctus dapibus ipsum sit amet laoreet. Fusce convallis sodales facilisis. Nullam pellentesque, ligula et hendrerit egestas, dolor diam dapibus leo, sit amet feugiat est metus sed purus. Phasellus iaculis neque sit amet urna aliquet pharetra. Nam at feugiat enim. Nam eget eros dictum elit porttitor congue a eget nibh.

Quisque ut nunc in enim fermentumLorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc facilisis, turpis eu placerat laoreet, augue lorem blandit enim, et blandit arcu nibh ut velit. Ut eget nunc porttitor, mattis lorem eget, interdum turpis. Nam aliquam augue dui, quis posuere erat porta a. Phasellus sodales metus elit, pellentesque mattis ipsum congue at. Maecenas luctus felis at efficitur bibendum. In ac est a ex condimentum tempor. Nulla pellentesque arcu sed varius tristique. Pellentesque gravida mauris hendrerit turpis finibus, a hendrerit arcu euismod.

Aliquam condimentum ligula vel diam elementum dignissim. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Morbi sit amet tempor ligula. Aenean at pharetra turpis. Suspendisse hendrerit velit nec neque imperdiet egestas. Phasellus id dui arcu. In eu turpis placerat, condimentum nunc in, egestas tellus. Nullam ornare eros placerat, posuere arcu vitae, euismod ipsum. Aenean porta ex id massa mollis, eu fringilla sapien auctor.

Nulla facilisi. Nulla rhoncus quam et leo aliquet consequat. Nullam sagittis porttitor dui, eget porttitor mi aliquet eget. Donec scelerisque nisi elit, vitae imperdiet mi vehicula sit amet. Vivamus sodales pulvinar nunc quis fringilla. Integer id quam arcu. Nulla porta vulputate ornare. Donec nec aliquam orci, eu imperdiet nisi. Phasellus ac posuere massa, in tempor mi. Vestibulum orci lectus, suscipit feugiat fermentum quis, maximus et ante. Proin convallis quis mauris quis tristique. Suspendisse in metus vel velit sagittis hendrerit id ac lorem. Nulla facilisi. Aenean ac egestas odio, et consequat ipsum. Fusce mattis pretium tempor. Vivamus eget accumsan orci, vitae varius leo.

Suspendisse id eros dolor. Donec tincidunt est nec lectus posuere condimentum. Phasellus tempor, tortor in eleifend vulputate, ligula dolor viverra urna, at ultrices erat arcu eu dolor. Duis hendrerit neque eu elit feugiat viverra a sit amet mauris. Curabitur vitae ultrices lacus. Integer id velit eleifend, posuere velit at, placerat urna. Donec felis magna, faucibus eu leo vel, tempor bibendum nibh.

Pellentesque imperdiet vehicula turpis ut rutrum. Integer euismod interdum justo, vitae volutpat ipsum condimentum vel. Quisque et accumsan massa. Nullam euismod at sem ac consequat. Fusce ullamcorper vestibulum urna non gravida. In hac habitasse platea dictumst. Sed eget nibh nec neque pretium vestibulum. Nam placerat nibh vitae nibh porta, in ultricies dui malesuada.

Aenean congue faucibus tortor convallis blandit. Pellentesque a ultrices mi. Suspendisse libero erat, lobortis vel magna a, tincidunt accumsan nisl. Etiam sed ligula odio. Cras condimentum arcu lorem, eu vulputate quam volutpat eget. Vestibulum eu molestie risus. Nam a urna elementum, hendrerit neque sit amet, fermentum augue.

Sed fringilla orci nisl. Curabitur luctus ipsum erat, vel scelerisque erat posuere lacinia. Etiam malesuada egestas urna, sit amet dapibus eros faucibus sed. Maecenas auctor ante in augue faucibus, id bibendum tellus pretium. Donec vitae tincidunt sapien. Donec at est nisl. Ut vitae orci a orci sodales dignissim ac a mi. Aliquam laoreet ante turpis, ultricies mattis erat ultrices et. Integer justo sem, mollis porta cursus vitae, ornare ut felis. Maecenas imperdiet odio eget orci congue sagittis. Curabitur at faucibus arcu, quis iaculis quam. Vestibulum eleifend ornare felis eget commodo. Sed tristique id turpis sed viverra. Sed quis quam non velit fringilla accumsan at nec mauris.

Pellentesque elementum eros vel orci luctus consequat euismod sit amet elit. Phasellus eget lorem vel nunc blandit ultrices. Nunc interdum purus nulla, et vestibulum lacus facilisis euismod. Quisque at blandit arcu. Vestibulum non lobortis nibh, sed cursus justo. Nunc quis leo auctor, imperdiet nulla et, porta quam. Duis vel ipsum non lacus iaculis bibendum ac ac nibh. Curabitur quis nisl sem. Phasellus nec tortor tellus.

Curabitur vel orci et sem finibus euismod id eget elit. Mauris est massa, accumsan quis pharetra vitae, aliquam iaculis nisi. Vivamus luctus dapibus ipsum sit amet laoreet. Fusce convallis sodales facilisis. Nullam pellentesque, ligula et hendrerit egestas, dolor diam dapibus leo, sit amet feugiat est metus sed purus. Phasellus iaculis neque sit amet urna aliquet pharetra. Nam at feugiat enim. Nam eget eros dictum elit porttitor congue a eget nibh.

Quisque ut nunc in enim fermentumLorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc facilisis, turpis eu placerat laoreet, augue lorem blandit enim, et blandit arcu nibh ut velit. Ut eget nunc porttitor, mattis lorem eget, interdum turpis. Nam aliquam augue dui, quis posuere erat porta a. Phasellus sodales metus elit, pellentesque mattis ipsum congue at. Maecenas luctus felis at efficitur bibendum. In ac est a ex condimentum tempor. Nulla pellentesque arcu sed varius tristique. Pellentesque gravida mauris hendrerit turpis finibus, a hendrerit arcu euismod.

Aliquam condimentum ligula vel diam elementum dignissim. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Morbi sit amet tempor ligula. Aenean at pharetra turpis. Suspendisse hendrerit velit nec neque imperdiet egestas. Phasellus id dui arcu. In eu turpis placerat, condimentum nunc in, egestas tellus. Nullam ornare eros placerat, posuere arcu vitae, euismod ipsum. Aenean porta ex id massa mollis, eu fringilla sapien auctor.

Nulla facilisi. Nulla rhoncus quam et leo aliquet consequat. Nullam sagittis porttitor dui, eget porttitor mi aliquet eget. Donec scelerisque nisi elit, vitae imperdiet mi vehicula sit amet. Vivamus sodales pulvinar nunc quis fringilla. Integer id quam arcu. Nulla porta vulputate ornare. Donec nec aliquam orci, eu imperdiet nisi. Phasellus ac posuere massa, in tempor mi. Vestibulum orci lectus, suscipit feugiat fermentum quis, maximus et ante. Proin convallis quis mauris quis tristique. Suspendisse in metus vel velit sagittis hendrerit id ac lorem. Nulla facilisi. Aenean ac egestas odio, et consequat ipsum. Fusce mattis pretium tempor. Vivamus eget accumsan orci, vitae varius leo.

Suspendisse id eros dolor. Donec tincidunt est nec lectus posuere condimentum. Phasellus tempor, tortor in eleifend vulputate, ligula dolor viverra urna, at ultrices erat arcu eu dolor. Duis hendrerit neque eu elit feugiat viverra a sit amet mauris. Curabitur vitae ultrices lacus. Integer id velit eleifend, posuere velit at, placerat urna. Donec felis magna, faucibus eu leo vel, tempor bibendum nibh.

Pellentesque imperdiet vehicula turpis ut rutrum. Integer euismod interdum justo, vitae volutpat ipsum condimentum vel. Quisque et accumsan massa. Nullam euismod at sem ac consequat. Fusce ullamcorper vestibulum urna non gravida. In hac habitasse platea dictumst. Sed eget nibh nec neque pretium vestibulum. Nam placerat nibh vitae nibh porta, in ultricies dui malesuada.

Aenean congue faucibus tortor convallis blandit. Pellentesque a ultrices mi. Suspendisse libero erat, lobortis vel magna a, tincidunt accumsan nisl. Etiam sed ligula odio. Cras condimentum arcu lorem, eu vulputate quam volutpat eget. Vestibulum eu molestie risus. Nam a urna elementum, hendrerit neque sit amet, fermentum augue.

Sed fringilla orci nisl. Curabitur luctus ipsum erat, vel scelerisque erat posuere lacinia. Etiam malesuada egestas urna, sit amet dapibus eros faucibus sed. Maecenas auctor ante in augue faucibus, id bibendum tellus pretium. Donec vitae tincidunt sapien. Donec at est nisl. Ut vitae orci a orci sodales dignissim ac a mi. Aliquam laoreet ante turpis, ultricies mattis erat ultrices et. Integer justo sem, mollis porta cursus vitae, ornare ut felis. Maecenas imperdiet odio eget orci congue sagittis. Curabitur at faucibus arcu, quis iaculis quam. Vestibulum eleifend ornare felis eget commodo. Sed tristique id turpis sed viverra. Sed quis quam non velit fringilla accumsan at nec mauris.

Pellentesque elementum eros vel orci luctus consequat euismod sit amet elit. Phasellus eget lorem vel nunc blandit ultrices. Nunc interdum purus nulla, et vestibulum lacus facilisis euismod. Quisque at blandit arcu. Vestibulum non lobortis nibh, sed cursus justo. Nunc quis leo auctor, imperdiet nulla et, porta quam. Duis vel ipsum non lacus iaculis bibendum ac ac nibh. Curabitur quis nisl sem. Phasellus nec tortor tellus.

Curabitur vel orci et sem finibus euismod id eget elit. Mauris est massa, accumsan quis pharetra vitae, aliquam iaculis nisi. Vivamus luctus dapibus ipsum sit amet laoreet. Fusce convallis sodales facilisis. Nullam pellentesque, ligula et hendrerit egestas, dolor diam dapibus leo, sit amet feugiat est metus sed purus. Phasellus iaculis neque sit amet urna aliquet pharetra. Nam at feugiat enim. Nam eget eros dictum elit porttitor congue a eget nibh.

			Quisque ut nunc in enim fermentum</p>
		<!-- /.content -->
    <!-- include scripts -->
   	<?php include 'includes/common-footer.php'; ?>
		<!-- /.indlude scripts -->
  </body>
</html>
