# Scarlett
A open source modern template for webhosting purposes

## Installation
  ### Requirements 
      1. Working apache webserver with php 
      (some rewriting rules are written in .htaccess feel free to modify it for nginx).
  ### Steps
      1. Just upload this archive to your desired directory.
      2. Browse at yourdomain/subdirectory(if placed under)/home
      
## Modification 
   1. Theres is some common parts for every pages like header, nav, footer you can find them under **includes/**
   2. every file has those common files included using php require('')
   3. Feel free to modify it to your expectation.
   4. This Template uses tawk.to intregration as for support
   5. All js codes are defined under assets/js/main.js
   6. All css styles are defined under assets/css/style.css
   7. Template uses bootstrap 3 feel free to make it compatible with bootstrap 4
   
 Please feel free to create a PR to upload your modifications.<br>
 And if you like this then don't forget to give this repo a star.<br>
 Issues section is open for suggestions and issues.<br>
 Thank you
